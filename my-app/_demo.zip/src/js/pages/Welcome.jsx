import React from 'react';
import Helper from '../configs/Helper.js';
import Layout from '../components/Layout.jsx';

export default class Welcome extends React.Component {

  makeRequest(){
    let value = Helper.getParameterByName('q');
    let params = {}
    if(value !== null || value !== ''){
      params = {termo: value};
    }

    Helper.request('get', '/api/filmes/lista', params, this.populateGrid);
  }

  populateGrid(data, error){
    console.log(data);
  }

  render(){
    return (
      <Layout>
        <div className="container">
        </div>
      </Layout>
    );
  }
};
