module.exports = {
  endpointApi : 'http://localhost:3020'
}
