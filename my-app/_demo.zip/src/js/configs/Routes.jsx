import React from 'react';
import { Route } from 'react-router'

/* Pages */
import NotFound from '../pages/NotFound.jsx';
import Welcome from '../pages/Welcome.jsx';

export default (
  <div>
    <Route path="/" component={Welcome} />
    <Route path="/alugados" component={Welcome} />
    <Route path="/logoff" component={Welcome} />
    <Route path="*" component={NotFound} />
  </div>
)
