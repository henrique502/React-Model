import React from 'react';
import { Button, Navbar, Nav } from 'react-bootstrap';
import { Link } from 'react-router';

export default class Header extends React.Component {

  render(){
    return (
      <Navbar>
        <Navbar.Header>
          <Navbar.Brand>
            <Link to="/">
              G Website
            </Link>
          </Navbar.Brand>
          <Navbar.Toggle />
        </Navbar.Header>
        <Navbar.Collapse>
          <Nav>
              <li><Link to="/" activeClassName="active">Filmes</Link></li>
              <li><Link to="/logoff" activeClassName="active">Sair</Link></li>
              <li><Link to="/alugados" activeClassName="active">Alugados</Link></li>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
