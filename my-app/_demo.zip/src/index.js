import React from 'react';
import ReactDOM from 'react-dom'
import { Route, Router, browserHistory } from 'react-router'

/* Pages */
import NotFound from './js/pages/NotFound.jsx';
import Welcome from './js/pages/Welcome.jsx';

browserHistory.listen(function(ev) {
  console.log('listen', ev.pathname);
});

ReactDOM.render(
    <div className="App">
      <Router history={browserHistory}>
        <Route path="/" component={Welcome} />
        <Route path="/alugados" component={Welcome} />
        <Route path="/logoff" component={Welcome} />
        <Route path="*" component={NotFound} />
      </Router>
    </div>
, document.getElementById('root'));
